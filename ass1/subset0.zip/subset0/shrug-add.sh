#!/bin/dash

for file in $@
do 
    # check invalid filename
    if ((echo "$file" | egrep -v '[a-zA-Z0-9\.\-\_]')||(echo "$file"|egrep -v '^[a-zA-Z0-9]')) >/dev/null
    then 
        echo "shrug-add:incorrect filename: $file"
        echo "filename should start with [a-zA-Z0-9] and only contain '.', '-' ,'_'  "
        exit 1
    else
        # copy valid file to index 
        cp "$file" ".shrug/index/$file"
    fi
done
