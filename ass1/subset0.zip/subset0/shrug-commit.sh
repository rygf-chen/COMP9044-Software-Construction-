#!/bin/dash

# get input
filename=$2
# check invalid filename which contain new-line character and '-'
if ((echo "$filename"| egrep '[\n]')||(echo "$filename"| egrep '^[-]')) >/dev/null
then
    echo "shrug-commit: incorrect filename:"$filename""
    echo "filname should not contain new-line character and does not begin with '-'"
    exit 1
fi
# get the last line of shrug-commit.log, which stored all diaries
lastline=`cat shrug-commit.log|tail -1`
# calculate the lines of diaries, it's helpful for append new diary
lastnum=`cat shrug-commit.log|wc -l`
num=`echo "$lastnum"|egrep '[0-9]'|sed 's/ //g'`
path=".shrug/index"
while true
do
    # create floders for each operation to store datas
    mkdir .shrug/branch/$num
    for file in $path/*
    do
        # copy files from index to branch(current status)
        cp "$file" ".shrug/branch"
        # copy files from index to its floder which sorted by opration times
        cp -fp "$file" ".shrug/branch/$num"
    done
    # print result and how many times it been changed
    echo "Committed as commit $num"
    # append when and what has been copied into shrug-commit.log
    echo "$num $filename" >>shrug-commit.log
    exit 1
done