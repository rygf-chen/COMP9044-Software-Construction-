#!/bin/dash

a=`cat shrug-commit.log|sort -r`
echo "$a"