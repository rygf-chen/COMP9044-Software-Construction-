#!/bin/dash

#floder
path=`echo "$@"|cut -d ' ' -f2|cut -d ':' -f1`
#filename
filename=`echo "$@"|cut -d ' ' -f2|cut -d ':' -f2`

#check the path invalid or not
if [ ! -e ".shrug/branch/$path/$filename" ]
then
    echo "$filename does not exist"
else
    #print output
    output=`cat ".shrug/branch/$path/$filename"`
    echo "$output"
fi
